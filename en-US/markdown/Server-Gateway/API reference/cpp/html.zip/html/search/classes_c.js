var searchData=
[
  ['tconnectioninfo_0',['TConnectionInfo',['../structagora_1_1rtc_1_1_t_connection_info.html',1,'agora::rtc']]]
];
