var searchData=
[
  ['max_5fuser_5faccount_5flength_5ftype_0',['MAX_USER_ACCOUNT_LENGTH_TYPE',['../namespaceagora_1_1rtc.html#a895ba93435851fd5ddbccd92e6d5356f',1,'agora::rtc']]],
  ['media_5fsource_5ftype_1',['MEDIA_SOURCE_TYPE',['../namespaceagora_1_1media.html#a4a2cdf6c50213a5df607bab1192dc488',1,'agora::media']]]
];
