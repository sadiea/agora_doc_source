var searchData=
[
  ['y_0',['y',['../structagora_1_1rtc_1_1_mixer_layout_config.html#a912dd842ec89503e1b1c42b1ca68f999',1,'agora::rtc::MixerLayoutConfig']]],
  ['ybuffer_1',['yBuffer',['../structagora_1_1media_1_1base_1_1_video_frame.html#ac6a40f331e3df3ca3cdb0fec738d9eb4',1,'agora::media::base::VideoFrame']]],
  ['ystride_2',['yStride',['../structagora_1_1media_1_1base_1_1_video_frame.html#ace4696b077b02bb29920c665f41727f7',1,'agora::media::base::VideoFrame']]]
];
