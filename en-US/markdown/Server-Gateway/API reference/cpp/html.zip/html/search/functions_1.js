var searchData=
[
  ['begin_0',['begin',['../classagora_1_1util_1_1_i_container.html#ae70323af66280efa3d53719729cd4218',1,'agora::util::IContainer::begin()'],['../classagora_1_1util_1_1_a_list.html#a0b328999f15a515e8e693d06c3c6a2ba',1,'agora::util::AList::begin()']]]
];
