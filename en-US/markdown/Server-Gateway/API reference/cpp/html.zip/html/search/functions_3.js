var searchData=
[
  ['data_0',['data',['../classagora_1_1util_1_1_i_string.html#aa537365ab423b040d8eecc2d8e782b5b',1,'agora::util::IString']]],
  ['delimagesource_1',['delImageSource',['../classagora_1_1rtc_1_1_i_video_mixer_source.html#a5288258b4932f1852810036f564f6e69',1,'agora::rtc::IVideoMixerSource']]],
  ['delstreamlayout_2',['delStreamLayout',['../classagora_1_1rtc_1_1_i_video_mixer_source.html#aa9341441b05797292f08d903bb497bfa',1,'agora::rtc::IVideoMixerSource']]],
  ['disconnect_3',['disconnect',['../classagora_1_1rtc_1_1_i_rtc_connection.html#aa83ca15b81922af3cb3f5d81221556e4',1,'agora::rtc::IRtcConnection::disconnect()'],['../classagora_1_1rtc_1_1_i_rtmp_connection.html#a7f018c26fe398ea7599951cf0ae94145',1,'agora::rtc::IRtmpConnection::disconnect()']]],
  ['downlinknetworkinfo_4',['DownlinkNetworkInfo',['../structagora_1_1rtc_1_1_downlink_network_info.html#ae58701bef80bf08bbc90bf4879bc318b',1,'agora::rtc::DownlinkNetworkInfo::DownlinkNetworkInfo()'],['../structagora_1_1rtc_1_1_downlink_network_info.html#abf0fc82873494c84e8bb6766001a9a8e',1,'agora::rtc::DownlinkNetworkInfo::DownlinkNetworkInfo(const DownlinkNetworkInfo &amp;info)']]]
];
