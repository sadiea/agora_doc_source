var searchData=
[
  ['agora_5fapi_0',['AGORA_API',['../_agora_base_8h.html#a252b591d88e72a09c7f1c974b67120d4',1,'AgoraBase.h']]],
  ['agora_5fcall_1',['AGORA_CALL',['../_agora_base_8h.html#a11f094aa4f9ddfe5cbd50318583a5e83',1,'AgoraBase.h']]],
  ['agora_5fdeprecated_2',['AGORA_DEPRECATED',['../_agora_base_8h.html#aec72624a8bf9442f13feab558c7273d2',1,'AgoraBase.h']]]
];
