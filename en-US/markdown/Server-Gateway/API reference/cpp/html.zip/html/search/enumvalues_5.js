var searchData=
[
  ['frame_5fheight_5f360_0',['FRAME_HEIGHT_360',['../namespaceagora_1_1rtc.html#a29e02d842f9dbb4284039e6ee31a99f0aa037e64f88bf0ca7c3d4d20956973c81',1,'agora::rtc']]],
  ['frame_5frate_5ffps_5f1_1',['FRAME_RATE_FPS_1',['../namespaceagora_1_1rtc.html#a382d0a93e80539155ebd729e362684f1a977f1cfdcf5b800f993482da6a173cd5',1,'agora::rtc']]],
  ['frame_5frate_5ffps_5f10_2',['FRAME_RATE_FPS_10',['../namespaceagora_1_1rtc.html#a382d0a93e80539155ebd729e362684f1aa12cac1b6fd0fae6e0d17e300bc16623',1,'agora::rtc']]],
  ['frame_5frate_5ffps_5f15_3',['FRAME_RATE_FPS_15',['../namespaceagora_1_1rtc.html#a382d0a93e80539155ebd729e362684f1a58bcbb5182037fb47ff30c42eee66710',1,'agora::rtc']]],
  ['frame_5frate_5ffps_5f24_4',['FRAME_RATE_FPS_24',['../namespaceagora_1_1rtc.html#a382d0a93e80539155ebd729e362684f1a076f14806cad9efc861f4cc1275578e4',1,'agora::rtc']]],
  ['frame_5frate_5ffps_5f30_5',['FRAME_RATE_FPS_30',['../namespaceagora_1_1rtc.html#a382d0a93e80539155ebd729e362684f1ac9ceedbdf97cbaa1c30a17773e7998db',1,'agora::rtc']]],
  ['frame_5frate_5ffps_5f60_6',['FRAME_RATE_FPS_60',['../namespaceagora_1_1rtc.html#a382d0a93e80539155ebd729e362684f1ae3b15e53bd5d9107a7aa13e6ed29b825',1,'agora::rtc']]],
  ['frame_5frate_5ffps_5f7_7',['FRAME_RATE_FPS_7',['../namespaceagora_1_1rtc.html#a382d0a93e80539155ebd729e362684f1ad04434616f09899ce747d9411099a3a1',1,'agora::rtc']]],
  ['frame_5ftype_5fpcm16_8',['FRAME_TYPE_PCM16',['../classagora_1_1media_1_1_i_audio_frame_observer_base.html#aa0e2b429cd1e9e55f60614adffa01daca434ef108ae62459f31354c79a4ee8d48',1,'agora::media::IAudioFrameObserverBase']]],
  ['frame_5fwidth_5f640_9',['FRAME_WIDTH_640',['../namespaceagora_1_1rtc.html#a2f07c4ed608d97da9e6bfbdb7723d9ddad29e62742c2779d2171051f8be3e9de9',1,'agora::rtc']]]
];
