var searchData=
[
  ['transcoded_5fvideo_5fsource_0',['TRANSCODED_VIDEO_SOURCE',['../namespaceagora_1_1media.html#a4a2cdf6c50213a5df607bab1192dc488ad3e8bb6642bf6b6b7c87d4113f636295',1,'agora::media']]],
  ['two_5fbytes_5fper_5fsample_1',['TWO_BYTES_PER_SAMPLE',['../namespaceagora_1_1rtc.html#a74143af8b2847d195090020877e7369da2ac2866da3a1e71f529fa2aa06eab97d',1,'agora::rtc']]]
];
