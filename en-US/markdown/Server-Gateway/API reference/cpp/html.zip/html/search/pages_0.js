var searchData=
[
  ['agora_20server_20gateway_20sdk_20c_2b_2b_20api_20reference_0',['Agora Server Gateway SDK C++ API Reference',['../index.html',1,'']]]
];
