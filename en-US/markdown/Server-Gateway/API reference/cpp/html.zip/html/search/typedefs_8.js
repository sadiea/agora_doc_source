var searchData=
[
  ['value_5ftype_0',['value_type',['../classagora_1_1util_1_1_auto_ptr.html#a49c5430118aa8f491afe93012b8573ff',1,'agora::util::AutoPtr::value_type()'],['../classagora_1_1util_1_1_a_output_iterator.html#a517f17f5574ceb64f0e13d3d56e88d7f',1,'agora::util::AOutputIterator::value_type()'],['../classagora_1_1util_1_1_a_list.html#ab3687fb54a4f875afb5d396a87b1c35a',1,'agora::util::AList::value_type()'],['../classagora_1_1_optional.html#a19bb7c7bc92c1fd4cd3db1fb4b5ad95d',1,'agora::Optional::value_type()']]],
  ['videoframe_1',['VideoFrame',['../classagora_1_1media_1_1_i_video_frame_observer.html#ae60399181e83d7e93ad759b2ab549b97',1,'agora::media::IVideoFrameObserver']]],
  ['view_5ft_2',['view_t',['../namespaceagora.html#a17bc4c41f9ee9f5f1c1f593fcc98fb16',1,'agora::view_t()'],['../namespaceagora_1_1media_1_1base.html#a7ff37c66afeabc64601c8c7ba36d8d04',1,'agora::media::base::view_t()']]]
];
