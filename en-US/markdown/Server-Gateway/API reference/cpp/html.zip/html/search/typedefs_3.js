var searchData=
[
  ['pointer_0',['pointer',['../classagora_1_1util_1_1_a_output_iterator.html#a6ca8f117e26ba18e913e1415a87cf0d2',1,'agora::util::AOutputIterator::pointer()'],['../classagora_1_1util_1_1_a_list.html#a29dad44bdadfa61b0aaab63b1769cf36',1,'agora::util::AList::pointer()']]],
  ['pointer_5ftype_1',['pointer_type',['../classagora_1_1util_1_1_auto_ptr.html#ad173e3764e303895329caf204900f67f',1,'agora::util::AutoPtr']]]
];
