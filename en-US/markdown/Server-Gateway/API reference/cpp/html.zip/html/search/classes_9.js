var searchData=
[
  ['peerdownlinkinfo_0',['PeerDownlinkInfo',['../structagora_1_1rtc_1_1_downlink_network_info_1_1_peer_downlink_info.html',1,'agora::rtc::DownlinkNetworkInfo']]]
];
