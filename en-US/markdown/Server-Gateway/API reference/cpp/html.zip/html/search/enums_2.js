var searchData=
[
  ['channel_5fprofile_5ftype_0',['CHANNEL_PROFILE_TYPE',['../namespaceagora.html#abc5eb7ac0efb18032c8383e528c490a2',1,'agora']]],
  ['client_5frole_5ftype_1',['CLIENT_ROLE_TYPE',['../namespaceagora_1_1rtc.html#a42f167813e36b5c11a8a1c659b877080',1,'agora::rtc']]],
  ['connection_5fchanged_5freason_5ftype_2',['CONNECTION_CHANGED_REASON_TYPE',['../namespaceagora_1_1rtc.html#a329573b5363b2065b4069e5bf6013144',1,'agora::rtc']]],
  ['connection_5fstate_5ftype_3',['CONNECTION_STATE_TYPE',['../namespaceagora_1_1rtc.html#a430364c3f2cbf4419b898077cf6977f7',1,'agora::rtc']]]
];
