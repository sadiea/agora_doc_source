var searchData=
[
  ['data_5f_0',['data_',['../structagora_1_1media_1_1base_1_1_audio_pcm_frame.html#aeab434caff2bab21af7e7c56c49835f5',1,'agora::media::base::AudioPcmFrame']]],
  ['decoderoutputframerate_1',['decoderOutputFrameRate',['../structagora_1_1rtc_1_1_remote_video_track_stats.html#aa9098e39c1df512c657f94497e8efde3',1,'agora::rtc::RemoteVideoTrackStats']]],
  ['default_5fconnection_5fid_2',['DEFAULT_CONNECTION_ID',['../namespaceagora_1_1rtc.html#af0e8e50f05a368140f51ab0b899f0833',1,'agora::rtc']]],
  ['default_5flog_5fsize_5fin_5fkb_3',['DEFAULT_LOG_SIZE_IN_KB',['../namespaceagora_1_1commons.html#a84cc048bca8d5313027da3cac9c99241',1,'agora::commons']]],
  ['degradationpreference_4',['degradationPreference',['../structagora_1_1rtc_1_1_video_encoder_configuration.html#a491316b0de64bf930938404b113f062f',1,'agora::rtc::VideoEncoderConfiguration']]],
  ['delay_5',['delay',['../structagora_1_1rtc_1_1_remote_video_track_stats.html#a4795e78dec0cb680556335ec968dc8a0',1,'agora::rtc::RemoteVideoTrackStats']]],
  ['delay_5festimate_5fms_6',['delay_estimate_ms',['../structagora_1_1rtc_1_1_remote_audio_track_stats.html#a63c7d054a826e9f38303da2bff580db2',1,'agora::rtc::RemoteAudioTrackStats']]],
  ['dimensions_7',['dimensions',['../structagora_1_1rtc_1_1_video_encoder_configuration.html#af31036bc7b00a4497716b1eb367d868d',1,'agora::rtc::VideoEncoderConfiguration::dimensions()'],['../structagora_1_1rtc_1_1_simulcast_stream_config.html#aed0edb719e55c84d9cb8d92a8611caf9',1,'agora::rtc::SimulcastStreamConfig::dimensions()']]],
  ['domainlimit_8',['domainLimit',['../structagora_1_1base_1_1_agora_service_configuration.html#a394fb9219d98e334a9659f24d7e416b6',1,'agora::base::AgoraServiceConfiguration']]],
  ['downlink_5fprocess_5ftime_5fms_9',['downlink_process_time_ms',['../structagora_1_1rtc_1_1_remote_video_track_stats.html#a61942ff207cde790e6d3fc1383afc6b0',1,'agora::rtc::RemoteVideoTrackStats']]],
  ['downlinkreport_10',['downlinkReport',['../structagora_1_1rtc_1_1_lastmile_probe_result.html#a08c34180e6bfaf39080529cb2a03dd4c',1,'agora::rtc::LastmileProbeResult']]],
  ['dropped_5faudio_5fframes_11',['dropped_audio_frames',['../structagora_1_1rtc_1_1_i_local_audio_track_1_1_local_audio_track_stats.html#a7729be9e0e5cff9bd6d2422b0b46a423',1,'agora::rtc::ILocalAudioTrack::LocalAudioTrackStats']]],
  ['dummy_5fconnection_5fid_12',['DUMMY_CONNECTION_ID',['../namespaceagora_1_1rtc.html#abaad7ca107078a076b2543a6c13fcec7',1,'agora::rtc']]],
  ['duration_13',['duration',['../structagora_1_1rtc_1_1_rtc_stats.html#a4b202fc7c44e9f17bdc089de6a45e4b8',1,'agora::rtc::RtcStats']]]
];
