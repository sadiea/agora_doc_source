var searchData=
[
  ['jitter_0',['jitter',['../structagora_1_1rtc_1_1_lastmile_probe_one_way_result.html#ad9a39e21981d9c2f16056bc9056a7b90',1,'agora::rtc::LastmileProbeOneWayResult']]],
  ['jitter_5fbuffer_5fdelay_1',['jitter_buffer_delay',['../structagora_1_1rtc_1_1_remote_audio_track_stats.html#a8a2436ad961d70cb248533b19f856551',1,'agora::rtc::RemoteAudioTrackStats']]]
];
