var searchData=
[
  ['queryinterface_0',['queryInterface',['../classagora_1_1util_1_1_auto_ptr.html#a264095d02f29ca4f1dfe5a0fa6a9d77b',1,'agora::util::AutoPtr::queryInterface()'],['../classagora_1_1base_1_1_i_engine_base.html#a2241d01eb43195800ed2e67652501e3d',1,'agora::base::IEngineBase::queryInterface()']]]
];
