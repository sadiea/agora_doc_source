var searchData=
[
  ['optional_5fdeclspec_5fempty_5fbases_0',['OPTIONAL_DECLSPEC_EMPTY_BASES',['../_agora_optional_8h.html#a8d5efac8d2fb9b035c65c59d5cc23c3c',1,'AgoraOptional.h']]],
  ['optional_5fenum_5fclass_1',['OPTIONAL_ENUM_CLASS',['../_i_agora_log_8h.html#a3ea42208eec7b17671bcbe99168828d1',1,'IAgoraLog.h']]],
  ['optional_5fenum_5fsize_5ft_2',['OPTIONAL_ENUM_SIZE_T',['../_agora_media_base_8h.html#a07ed4a9bfb7d4064bc44e83899e8c6a7',1,'AgoraMediaBase.h']]],
  ['optional_5flog_5flevel_5fspecifier_3',['OPTIONAL_LOG_LEVEL_SPECIFIER',['../_i_agora_log_8h.html#a8a5ca78061307558734ff8376d535012',1,'IAgoraLog.h']]],
  ['optional_5fnullptr_4',['OPTIONAL_NULLPTR',['../_agora_base_8h.html#af14e33a0c818e1335a28729a3328130b',1,'AgoraBase.h']]],
  ['optional_5foverride_5',['OPTIONAL_OVERRIDE',['../_n_g_i_agora_video_track_8h.html#aa409f96536d7fd89fa902380fcd0f787',1,'NGIAgoraVideoTrack.h']]],
  ['optional_5fprocessresult_5fspecifier_6',['OPTIONAL_PROCESSRESULT_SPECIFIER',['../_n_g_i_agora_media_node_8h.html#a01e09dec446ee5ebf9c679001802bd53',1,'NGIAgoraMediaNode.h']]]
];
