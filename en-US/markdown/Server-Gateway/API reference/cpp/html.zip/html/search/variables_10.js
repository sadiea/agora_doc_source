var searchData=
[
  ['qoe_5fquality_0',['qoe_quality',['../structagora_1_1rtc_1_1_remote_audio_track_stats.html#ab8bee9eadfdb6ce7256ccb132cd700de',1,'agora::rtc::RemoteAudioTrackStats']]],
  ['quality_1',['quality',['../structagora_1_1rtc_1_1_remote_audio_track_stats.html#ac063b2b150693d32798006a2d397c70e',1,'agora::rtc::RemoteAudioTrackStats']]],
  ['quality_5fadapt_5findication_2',['quality_adapt_indication',['../structagora_1_1rtc_1_1_local_video_track_stats.html#a8883f7355db36f22fce5567297833c62',1,'agora::rtc::LocalVideoTrackStats']]],
  ['quality_5fchanged_5freason_3',['quality_changed_reason',['../structagora_1_1rtc_1_1_remote_audio_track_stats.html#a695c5eab30159cfdf75a46c4587f17fc',1,'agora::rtc::RemoteAudioTrackStats']]]
];
