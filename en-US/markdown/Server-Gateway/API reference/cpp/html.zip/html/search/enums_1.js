var searchData=
[
  ['bytes_5fper_5fsample_0',['BYTES_PER_SAMPLE',['../namespaceagora_1_1rtc.html#a74143af8b2847d195090020877e7369d',1,'agora::rtc']]]
];
