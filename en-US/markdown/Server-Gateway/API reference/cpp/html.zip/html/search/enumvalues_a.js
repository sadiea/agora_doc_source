var searchData=
[
  ['network_5ftype_5fdisconnected_0',['NETWORK_TYPE_DISCONNECTED',['../namespaceagora_1_1rtc.html#ab5e06b511f978f1a997008401da46505a088190434b4a1271f4e5849cd41fc9fe',1,'agora::rtc']]],
  ['network_5ftype_5flan_1',['NETWORK_TYPE_LAN',['../namespaceagora_1_1rtc.html#ab5e06b511f978f1a997008401da46505abc2d98d2aa184f7766cc1d480b0302b3',1,'agora::rtc']]],
  ['network_5ftype_5fmobile_5f2g_2',['NETWORK_TYPE_MOBILE_2G',['../namespaceagora_1_1rtc.html#ab5e06b511f978f1a997008401da46505ac93cdd7ba1c6004cd959a407bb9aaf0b',1,'agora::rtc']]],
  ['network_5ftype_5fmobile_5f3g_3',['NETWORK_TYPE_MOBILE_3G',['../namespaceagora_1_1rtc.html#ab5e06b511f978f1a997008401da46505a3f70717344b70437028cb9519ec07900',1,'agora::rtc']]],
  ['network_5ftype_5fmobile_5f4g_4',['NETWORK_TYPE_MOBILE_4G',['../namespaceagora_1_1rtc.html#ab5e06b511f978f1a997008401da46505a748a1c812bf1a7026aeca60322e0c126',1,'agora::rtc']]],
  ['network_5ftype_5funknown_5',['NETWORK_TYPE_UNKNOWN',['../namespaceagora_1_1rtc.html#ab5e06b511f978f1a997008401da46505aaffd83f62604659b799989fc9755d773',1,'agora::rtc']]],
  ['network_5ftype_5fwifi_6',['NETWORK_TYPE_WIFI',['../namespaceagora_1_1rtc.html#ab5e06b511f978f1a997008401da46505abf47c9dede3e20c97f8d4c8e2050c4df',1,'agora::rtc']]],
  ['none_7',['None',['../classagora_1_1rtc_1_1_i_rtmp_local_user.html#a692c5ab59e1da5664535c3f4df4789b6ada1eb20a5aca64378518617f22367623',1,'agora::rtc::IRtmpLocalUser']]]
];
