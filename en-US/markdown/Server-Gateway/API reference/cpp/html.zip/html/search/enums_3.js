var searchData=
[
  ['degradation_5fpreference_0',['DEGRADATION_PREFERENCE',['../namespaceagora_1_1rtc.html#ae02c6d4b2848c21a502e4c1643d85ef6',1,'agora::rtc']]]
];
