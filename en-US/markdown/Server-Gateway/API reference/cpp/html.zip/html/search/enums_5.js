var searchData=
[
  ['frame_5fheight_0',['FRAME_HEIGHT',['../namespaceagora_1_1rtc.html#a29e02d842f9dbb4284039e6ee31a99f0',1,'agora::rtc']]],
  ['frame_5frate_1',['FRAME_RATE',['../namespaceagora_1_1rtc.html#a382d0a93e80539155ebd729e362684f1',1,'agora::rtc']]],
  ['frame_5fwidth_2',['FRAME_WIDTH',['../namespaceagora_1_1rtc.html#a2f07c4ed608d97da9e6bfbdb7723d9dd',1,'agora::rtc']]]
];
