var searchData=
[
  ['tconnectioninfo_0',['TConnectionInfo',['../structagora_1_1rtc_1_1_t_connection_info.html#a3a212c02b3b19b12de6c787dfb861bd3',1,'agora::rtc::TConnectionInfo']]]
];
