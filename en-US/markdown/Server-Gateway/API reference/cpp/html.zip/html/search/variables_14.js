var searchData=
[
  ['ubuffer_0',['uBuffer',['../structagora_1_1media_1_1base_1_1_video_frame.html#af402b28334e4ed778166c31f89891727',1,'agora::media::base::VideoFrame']]],
  ['uid_1',['uid',['../structagora_1_1rtc_1_1_encoded_video_frame_info.html#a6288d2b19e91db86a760a92e0b3505d4',1,'agora::rtc::EncodedVideoFrameInfo::uid()'],['../structagora_1_1rtc_1_1_downlink_network_info_1_1_peer_downlink_info.html#aa8fe50388c0151b0496d4caeb12b7bc6',1,'agora::rtc::DownlinkNetworkInfo::PeerDownlinkInfo::uid()'],['../structagora_1_1rtc_1_1_user_info.html#af25a49fef3a90b76338b59a0657bb2aa',1,'agora::rtc::UserInfo::uid()'],['../structagora_1_1rtc_1_1_remote_audio_track_stats.html#a1931c43dffe95295e1a47046db95459e',1,'agora::rtc::RemoteAudioTrackStats::uid()'],['../structagora_1_1rtc_1_1_remote_video_track_stats.html#a79190b1a920b230804d2eb0690bb2a3f',1,'agora::rtc::RemoteVideoTrackStats::uid()']]],
  ['uplink_5fcost_5ftime_5fms_2',['uplink_cost_time_ms',['../structagora_1_1rtc_1_1_local_video_track_stats.html#acde57fa126be7e9dbeec10596dab9de5',1,'agora::rtc::LocalVideoTrackStats']]],
  ['uplinkreport_3',['uplinkReport',['../structagora_1_1rtc_1_1_lastmile_probe_result.html#a8f7a1bf3e42a6d0ae7c8a8bf672846b3',1,'agora::rtc::LastmileProbeResult']]],
  ['useraccount_4',['userAccount',['../structagora_1_1rtc_1_1_user_info.html#a0dd954d149562bd2578a223927a59d4b',1,'agora::rtc::UserInfo']]],
  ['usercount_5',['userCount',['../structagora_1_1rtc_1_1_rtc_stats.html#a296afc59475c4b6fa89d4e685eacca7e',1,'agora::rtc::RtcStats']]],
  ['userid_6',['userId',['../structagora_1_1_user_info.html#ad758f7157869a89395b0423c9b399e03',1,'agora::UserInfo::userId()'],['../structagora_1_1rtc_1_1_audio_volume_information.html#aaacd9c3a4cb5e6a7f05c404509af03b0',1,'agora::rtc::AudioVolumeInformation::userId()']]],
  ['usestringuid_7',['useStringUid',['../structagora_1_1base_1_1_agora_service_configuration.html#a54744e3516aab7a8a86e2966cbf8b1c6',1,'agora::base::AgoraServiceConfiguration']]],
  ['ustride_8',['uStride',['../structagora_1_1media_1_1base_1_1_video_frame.html#a1b0323a19dbf8520771b2ad3ecf41d54',1,'agora::media::base::VideoFrame']]]
];
