var searchData=
[
  ['video_5fbuffer_5ftype_0',['VIDEO_BUFFER_TYPE',['../structagora_1_1media_1_1base_1_1_external_video_frame.html#aa8de65fda03edf2a02cad8a522cc9fc2',1,'agora::media::base::ExternalVideoFrame']]],
  ['video_5fcodec_5ftype_1',['VIDEO_CODEC_TYPE',['../namespaceagora_1_1rtc.html#a79ccac2a3f394deae680761453d15215',1,'agora::rtc']]],
  ['video_5fframe_5fprocess_5fmode_2',['VIDEO_FRAME_PROCESS_MODE',['../classagora_1_1media_1_1_i_video_frame_observer.html#aa0a690ef35d3813937a396d39ef74e65',1,'agora::media::IVideoFrameObserver']]],
  ['video_5fframe_5ftype_3',['VIDEO_FRAME_TYPE',['../namespaceagora_1_1rtc.html#aecdd48fd8c80e68e723e4bea97cb4281',1,'agora::rtc']]],
  ['video_5fmirror_5fmode_5ftype_4',['VIDEO_MIRROR_MODE_TYPE',['../namespaceagora_1_1rtc.html#a8f684b7ea22afd313ea9fbff6d6aea13',1,'agora::rtc']]],
  ['video_5fmodule_5fposition_5',['VIDEO_MODULE_POSITION',['../namespaceagora_1_1media_1_1base.html#a25dc43f56939c083dddd771234b5caf5',1,'agora::media::base']]],
  ['video_5forientation_6',['VIDEO_ORIENTATION',['../namespaceagora_1_1rtc.html#aedbc3d09c641940779abc983aa3ee3bc',1,'agora::rtc']]],
  ['video_5fpixel_5fformat_7',['VIDEO_PIXEL_FORMAT',['../namespaceagora_1_1media_1_1base.html#ab530007c5b083146b9cebefb46f931e2',1,'agora::media::base']]],
  ['video_5fsource_5ftype_8',['VIDEO_SOURCE_TYPE',['../namespaceagora_1_1rtc.html#ac6699b3c40e047af097d877115dde751',1,'agora::rtc']]],
  ['video_5fstream_5ftype_9',['VIDEO_STREAM_TYPE',['../namespaceagora_1_1rtc.html#a5f78a8dc3552e4ec308270198dd49b55',1,'agora::rtc']]],
  ['videobitrateadjusttype_10',['VideoBitrateAdjustType',['../classagora_1_1rtc_1_1_i_rtmp_local_user.html#a692c5ab59e1da5664535c3f4df4789b6',1,'agora::rtc::IRtmpLocalUser']]],
  ['videotracktype_11',['VideoTrackType',['../namespaceagora_1_1rtc.html#a1a5e96c615b82373b20c842f8b20ccf9',1,'agora::rtc']]]
];
