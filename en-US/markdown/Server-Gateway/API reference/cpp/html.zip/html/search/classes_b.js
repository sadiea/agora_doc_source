var searchData=
[
  ['senderoptions_0',['SenderOptions',['../structagora_1_1base_1_1_sender_options.html',1,'agora::base']]],
  ['simulcaststreamconfig_1',['SimulcastStreamConfig',['../structagora_1_1rtc_1_1_simulcast_stream_config.html',1,'agora::rtc']]]
];
