var searchData=
[
  ['any_5fdocument_5ft_0',['any_document_t',['../namespaceagora.html#a53ad2a97475c0fe887004d50085a99b8',1,'agora']]],
  ['astring_1',['AString',['../namespaceagora_1_1util.html#ac12a22b3b5dd9c39cde0aa3e2c0a9a80',1,'agora::util']]]
];
