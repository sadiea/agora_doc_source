var searchData=
[
  ['quality_5fadapt_5findication_0',['QUALITY_ADAPT_INDICATION',['../namespaceagora_1_1rtc.html#ab8ebad21ea6a6b579c03f05c4533a071',1,'agora::rtc']]],
  ['quality_5ftype_1',['QUALITY_TYPE',['../namespaceagora_1_1rtc.html#aeaf419fcafaa4d58da8b6d8718e31891',1,'agora::rtc']]]
];
