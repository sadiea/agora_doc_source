var searchData=
[
  ['downlinknetworkinfo_0',['DownlinkNetworkInfo',['../structagora_1_1rtc_1_1_downlink_network_info.html',1,'agora::rtc']]]
];
