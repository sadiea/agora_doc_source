var searchData=
[
  ['next_0',['next',['../classagora_1_1util_1_1_i_iterator.html#ae676c832ec4e868a83fd85091d264b65',1,'agora::util::IIterator']]],
  ['nullopt_1',['nullopt',['../namespaceagora.html#adba8480af8b8c0a9a331e1a21b888e58',1,'agora']]],
  ['nullopt_5ft_2',['nullopt_t',['../structagora_1_1nullopt__t.html#ac2379ca12d73f78996559606dc3ee4bf',1,'agora::nullopt_t']]]
];
