var searchData=
[
  ['user_5fmedia_5finfo_0',['USER_MEDIA_INFO',['../classagora_1_1rtc_1_1_i_local_user_observer.html#aebf5fda0b9fa8f8921fab72a2bf6556a',1,'agora::rtc::ILocalUserObserver']]],
  ['user_5foffline_5freason_5ftype_1',['USER_OFFLINE_REASON_TYPE',['../namespaceagora_1_1rtc.html#a56ebc30a718928cb6998ba1424900fef',1,'agora::rtc']]]
];
