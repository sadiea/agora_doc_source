var searchData=
[
  ['copyableautoptr_0',['CopyableAutoPtr',['../classagora_1_1util_1_1_copyable_auto_ptr.html',1,'agora::util']]],
  ['copyassignable_1',['CopyAssignable',['../structagora_1_1internal_1_1_copy_assignable.html',1,'agora::internal']]],
  ['copyassignable_3c_20false_20_3e_2',['CopyAssignable&lt; false &gt;',['../structagora_1_1internal_1_1_copy_assignable_3_01false_01_4.html',1,'agora::internal']]],
  ['copyconstructible_3',['CopyConstructible',['../structagora_1_1internal_1_1_copy_constructible.html',1,'agora::internal']]],
  ['copyconstructible_3c_20false_20_3e_4',['CopyConstructible&lt; false &gt;',['../structagora_1_1internal_1_1_copy_constructible_3_01false_01_4.html',1,'agora::internal']]]
];
