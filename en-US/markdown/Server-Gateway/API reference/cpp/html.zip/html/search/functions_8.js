var searchData=
[
  ['init_0',['Init',['../structagora_1_1internal_1_1_optional_storage_base.html#a71414363525e1ef5d245e140c5d1a9a8',1,'agora::internal::OptionalStorageBase']]],
  ['initialize_1',['initialize',['../classagora_1_1base_1_1_i_agora_service.html#a6f1fb6e792c564dee46903cbb3bc35fc',1,'agora::base::IAgoraService']]],
  ['initorassign_2',['InitOrAssign',['../classagora_1_1internal_1_1_optional_base.html#a7f862fd39b3a997ed9c9a28f2a200cd0',1,'agora::internal::OptionalBase']]],
  ['isenabled_3',['isEnabled',['../classagora_1_1rtc_1_1_i_local_audio_track.html#a103aa5dd48b949e735101e0c2825376a',1,'agora::rtc::ILocalAudioTrack']]],
  ['isexternal_4',['isExternal',['../classagora_1_1media_1_1_i_video_frame_observer.html#a2d6db5dbead74855002812bac087c9e2',1,'agora::media::IVideoFrameObserver']]]
];
