var searchData=
[
  ['network_5ftransport_5fdelay_0',['network_transport_delay',['../structagora_1_1rtc_1_1_remote_audio_track_stats.html#a645e1aba21fbce5c4ec2d65968ae8fc8',1,'agora::rtc::RemoteAudioTrackStats']]],
  ['num_5fchannels_1',['num_channels',['../structagora_1_1rtc_1_1_remote_audio_track_stats.html#afe285c66a151c0d6bb4df8896f758176',1,'agora::rtc::RemoteAudioTrackStats']]],
  ['num_5fchannels_5f_2',['num_channels_',['../structagora_1_1media_1_1base_1_1_audio_pcm_frame.html#ab937bed9d37df5df1c476de0ec971908',1,'agora::media::base::AudioPcmFrame']]],
  ['number_5fof_5fstreams_3',['number_of_streams',['../structagora_1_1rtc_1_1_local_video_track_stats.html#a5ce410bfa5c3386d54757233d66628b4',1,'agora::rtc::LocalVideoTrackStats']]],
  ['numberofchannels_4',['numberOfChannels',['../structagora_1_1rtc_1_1_encoded_audio_frame_info.html#aa60140fa8c89fcd6566845d2e4f2d293',1,'agora::rtc::EncodedAudioFrameInfo::numberOfChannels()'],['../structagora_1_1rtc_1_1_audio_subscription_options.html#aa7285c0bde75d7b275d05b5c1c97b59f',1,'agora::rtc::AudioSubscriptionOptions::numberOfChannels()'],['../structagora_1_1rtc_1_1_rtmp_streaming_audio_configuration.html#a031a94dccb8fbd9672a4872139ab0bcd',1,'agora::rtc::RtmpStreamingAudioConfiguration::numberOfChannels()']]],
  ['numchannels_5',['numChannels',['../structagora_1_1rtc_1_1_local_audio_stats.html#ac0a2499999af77899a170ec608b8ebe9',1,'agora::rtc::LocalAudioStats']]]
];
