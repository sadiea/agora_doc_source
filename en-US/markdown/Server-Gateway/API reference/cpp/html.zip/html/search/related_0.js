var searchData=
[
  ['optionalbase_0',['OptionalBase',['../classagora_1_1internal_1_1_optional_base.html#ad0a2d544a7adc9646c13843053119e26',1,'agora::internal::OptionalBase']]]
];
