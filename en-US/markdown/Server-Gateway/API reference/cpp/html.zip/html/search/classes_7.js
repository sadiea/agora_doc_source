var searchData=
[
  ['nullopt_5ft_0',['nullopt_t',['../structagora_1_1nullopt__t.html',1,'agora']]]
];
