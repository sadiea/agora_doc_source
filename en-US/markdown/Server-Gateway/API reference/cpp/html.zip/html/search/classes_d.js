var searchData=
[
  ['uplinknetworkinfo_0',['UplinkNetworkInfo',['../structagora_1_1rtc_1_1_uplink_network_info.html',1,'agora::rtc']]],
  ['userinfo_1',['UserInfo',['../structagora_1_1rtc_1_1_user_info.html',1,'agora::rtc::UserInfo'],['../structagora_1_1_user_info.html',1,'agora::UserInfo']]]
];
