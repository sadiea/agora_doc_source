var searchData=
[
  ['reference_0',['reference',['../classagora_1_1util_1_1_a_output_iterator.html#a1d1a3a7c57472dd8f59043eadd68dcb3',1,'agora::util::AOutputIterator::reference()'],['../classagora_1_1util_1_1_a_list.html#a79d2bffadae572eb396ebf31e0ebd75c',1,'agora::util::AList::reference()']]]
];
