var searchData=
[
  ['orientation_5fmode_5fadaptive_0',['ORIENTATION_MODE_ADAPTIVE',['../namespaceagora_1_1rtc.html#af3d825e24a1e5dcfb74279c69b81d0c7a6c9c916656d47771664b0696fbaa39bc',1,'agora::rtc']]],
  ['orientation_5fmode_5ffixed_5flandscape_1',['ORIENTATION_MODE_FIXED_LANDSCAPE',['../namespaceagora_1_1rtc.html#af3d825e24a1e5dcfb74279c69b81d0c7ac8e505f519b124299c5977b21df29c21',1,'agora::rtc']]],
  ['orientation_5fmode_5ffixed_5fportrait_2',['ORIENTATION_MODE_FIXED_PORTRAIT',['../namespaceagora_1_1rtc.html#af3d825e24a1e5dcfb74279c69b81d0c7a26abe8e035ec0867b3603ffccc9248f8',1,'agora::rtc']]]
];
