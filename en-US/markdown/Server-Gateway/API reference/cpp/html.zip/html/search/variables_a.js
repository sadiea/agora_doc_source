var searchData=
[
  ['kmaxcodecnamelength_0',['kMaxCodecNameLength',['../namespaceagora_1_1media_1_1base.html#a08321784e3dc1d0e3f888153a4bdff91',1,'agora::media::base']]]
];
