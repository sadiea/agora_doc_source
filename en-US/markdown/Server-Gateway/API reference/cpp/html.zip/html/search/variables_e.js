var searchData=
[
  ['optional_5fenum_5fsize_5ft_0',['OPTIONAL_ENUM_SIZE_T',['../structagora_1_1media_1_1base_1_1_audio_pcm_frame.html#af7d1298efa6e07c0172ea4e781b849b8',1,'agora::media::base::AudioPcmFrame']]],
  ['orientationmode_1',['orientationMode',['../structagora_1_1rtc_1_1_video_encoder_configuration.html#acdd8e209a4e4dafceef5879988f39fb6',1,'agora::rtc::VideoEncoderConfiguration::orientationMode()'],['../structagora_1_1rtc_1_1_rtmp_streaming_video_configuration.html#ab0414e65411d9e226ab4e70c68b5bc25',1,'agora::rtc::RtmpStreamingVideoConfiguration::orientationMode()']]],
  ['owneruid_2',['ownerUid',['../structagora_1_1rtc_1_1_video_track_info.html#a2c08de53f8efaf73d13dba7058e32f55',1,'agora::rtc::VideoTrackInfo']]]
];
