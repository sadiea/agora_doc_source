var searchData=
[
  ['videodimensions_0',['VideoDimensions',['../structagora_1_1rtc_1_1_video_dimensions.html',1,'agora::rtc']]],
  ['videoencoderconfiguration_1',['VideoEncoderConfiguration',['../structagora_1_1rtc_1_1_video_encoder_configuration.html',1,'agora::rtc']]],
  ['videoframe_2',['VideoFrame',['../structagora_1_1media_1_1base_1_1_video_frame.html',1,'agora::media::base']]],
  ['videosubscriptionoptions_3',['VideoSubscriptionOptions',['../structagora_1_1rtc_1_1_video_subscription_options.html',1,'agora::rtc']]],
  ['videotrackinfo_4',['VideoTrackInfo',['../structagora_1_1rtc_1_1_video_track_info.html',1,'agora::rtc']]]
];
