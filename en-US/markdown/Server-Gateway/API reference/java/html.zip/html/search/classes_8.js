var searchData=
[
  ['sdk_0',['SDK',['../classio_1_1agora_1_1rtc_1_1_s_d_k.html',1,'io::agora::rtc']]],
  ['senderoptions_1',['SenderOptions',['../classio_1_1agora_1_1rtc_1_1_sender_options.html',1,'io::agora::rtc']]],
  ['simulcaststreamconfig_2',['SimulcastStreamConfig',['../classio_1_1agora_1_1rtc_1_1_simulcast_stream_config.html',1,'io::agora::rtc']]]
];
