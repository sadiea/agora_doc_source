var searchData=
[
  ['uplinknetworkinfo_0',['UplinkNetworkInfo',['../classio_1_1agora_1_1rtc_1_1_uplink_network_info.html',1,'io::agora::rtc']]],
  ['useraudiospectruminfo_1',['UserAudioSpectrumInfo',['../classio_1_1agora_1_1rtc_1_1_user_audio_spectrum_info.html',1,'io::agora::rtc']]],
  ['userinfo_2',['UserInfo',['../classio_1_1agora_1_1rtc_1_1_user_info.html',1,'io::agora::rtc']]]
];
