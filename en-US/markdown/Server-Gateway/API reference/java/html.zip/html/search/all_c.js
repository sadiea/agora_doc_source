var searchData=
[
  ['transcodinguser_0',['TranscodingUser',['../classio_1_1agora_1_1rtc_1_1_transcoding_user.html',1,'io.agora.rtc.TranscodingUser'],['../classio_1_1agora_1_1rtc_1_1_transcoding_user.html#a65f5595de9370c548ffdfb6de3e8cee2',1,'io.agora.rtc.TranscodingUser.TranscodingUser()'],['../classio_1_1agora_1_1rtc_1_1_transcoding_user.html#aa2375ee46cba6fc1631a9ae42eb7c9aa',1,'io.agora.rtc.TranscodingUser.TranscodingUser(int uid, java.lang.String userId, int x, int y, int width, int height, int zOrder, double alpha, int audioChannel)']]],
  ['transcodinguser_2ejava_1',['TranscodingUser.java',['../_transcoding_user_8java.html',1,'']]],
  ['transcodingvideostream_2',['TranscodingVideoStream',['../classio_1_1agora_1_1rtc_1_1_transcoding_video_stream.html',1,'io.agora.rtc.TranscodingVideoStream'],['../classio_1_1agora_1_1rtc_1_1_transcoding_video_stream.html#af70bf2d9bbf732f2b00f3038ce4171bb',1,'io.agora.rtc.TranscodingVideoStream.TranscodingVideoStream()'],['../classio_1_1agora_1_1rtc_1_1_transcoding_video_stream.html#a13db0b0a9c1ddd72e3a14d2565a08511',1,'io.agora.rtc.TranscodingVideoStream.TranscodingVideoStream(int sourceType, int remoteUserUid, java.lang.String imageUrl, int x, int y, int width, int height, int zOrder, double alpha, int mirror)']]],
  ['transcodingvideostream_2ejava_3',['TranscodingVideoStream.java',['../_transcoding_video_stream_8java.html',1,'']]]
];
