var searchData=
[
  ['watermarkratio_2ejava_0',['WatermarkRatio.java',['../_watermark_ratio_8java.html',1,'']]]
];
