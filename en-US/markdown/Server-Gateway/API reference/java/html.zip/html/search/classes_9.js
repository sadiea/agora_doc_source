var searchData=
[
  ['transcodinguser_0',['TranscodingUser',['../classio_1_1agora_1_1rtc_1_1_transcoding_user.html',1,'io::agora::rtc']]],
  ['transcodingvideostream_1',['TranscodingVideoStream',['../classio_1_1agora_1_1rtc_1_1_transcoding_video_stream.html',1,'io::agora::rtc']]]
];
