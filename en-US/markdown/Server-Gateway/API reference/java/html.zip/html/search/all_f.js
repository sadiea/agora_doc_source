var searchData=
[
  ['watermarkratio_0',['WatermarkRatio',['../classio_1_1agora_1_1rtc_1_1_watermark_ratio.html',1,'io.agora.rtc.WatermarkRatio'],['../classio_1_1agora_1_1rtc_1_1_watermark_ratio.html#a57b6e51a59fe6273c676cecdf7b3b217',1,'io.agora.rtc.WatermarkRatio.WatermarkRatio()'],['../classio_1_1agora_1_1rtc_1_1_watermark_ratio.html#a003ba4890f1eb6f548aeb9d5a8ef9a8b',1,'io.agora.rtc.WatermarkRatio.WatermarkRatio(float xRatio, float yRatio, float widthRatio)']]],
  ['watermarkratio_2ejava_1',['WatermarkRatio.java',['../_watermark_ratio_8java.html',1,'']]]
];
