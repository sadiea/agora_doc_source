var searchData=
[
  ['watermarkratio_0',['WatermarkRatio',['../classio_1_1agora_1_1rtc_1_1_watermark_ratio.html',1,'io::agora::rtc']]]
];
