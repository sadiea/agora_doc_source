var searchData=
[
  ['peerdownlinkinfo_0',['PeerDownlinkInfo',['../classio_1_1agora_1_1rtc_1_1_peer_downlink_info.html',1,'io.agora.rtc.PeerDownlinkInfo'],['../classio_1_1agora_1_1rtc_1_1_peer_downlink_info.html#aada640a7f694cead9085496396709d42',1,'io.agora.rtc.PeerDownlinkInfo.PeerDownlinkInfo()'],['../classio_1_1agora_1_1rtc_1_1_peer_downlink_info.html#ad813a7240b6def943f443d72f3c5ad8a',1,'io.agora.rtc.PeerDownlinkInfo.PeerDownlinkInfo(java.lang.String uid, int streamType, int currentDownscaleLevel, int expectedBitrateBps)']]],
  ['peerdownlinkinfo_2ejava_1',['PeerDownlinkInfo.java',['../_peer_downlink_info_8java.html',1,'']]],
  ['publishaudio_2',['publishAudio',['../classio_1_1agora_1_1rtc_1_1_agora_local_user.html#a30711bbe175b24277d4cd977cb544d4e',1,'io::agora::rtc::AgoraLocalUser']]],
  ['publishvideo_3',['publishVideo',['../classio_1_1agora_1_1rtc_1_1_agora_local_user.html#aa8026a2b75cddf74b45149861b87d053',1,'io::agora::rtc::AgoraLocalUser']]]
];
